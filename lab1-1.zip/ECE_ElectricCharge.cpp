/*
Author:  Hongkun Xiong
Date last modified: 24/9/2023
Organization: ECE6122 Class

Description:
A cpp file of ECE_ElectricCharge,it implements the function of class ECE_ElectricCharge.
*/

#include "ECE_ElectricCharge.h"

//Initialize the protected member variables with the provided values.
ECE_ElectricCharge::ECE_ElectricCharge(double x, double y, double z, double q) : x(x), y(y), z(z), q(q) {}

//Modify the location of the point charge.
void ECE_ElectricCharge::setLocation(double x, double y, double z) {
    this->x = x;
    this->y = y;
    this->z = z;
}

//Modify the charge of the point charge.
void ECE_ElectricCharge::setCharge(double q) {
    this->q = q;
}

/*
Author:  Hongkun Xiong
Date last modified: 24/9/2023
Organization: ECE6122 Class

Description:
A cpp file of ECE_ElectricField,it implements the ECE_ElectricField class inheritated from class ElectricCharge.
*/

#include "ECE_ElectricField.h"
#include <cmath>

const double k = 9.0e9; // a const variable and its unit is N��m^2/C^2


//initialize the inherited member variables and sets the electric field components to zero
ECE_ElectricField::ECE_ElectricField(double x, double y, double z, double q) : ECE_ElectricCharge(x, y, z, q) {
    computeFieldAt(x, y, z);
}

//computes the electric field at a specified location based on formula
void ECE_ElectricField::computeFieldAt(double x, double y, double z) {
    double dx = x - this->x;
    double dy = y - this->y;
    double dz = z - this->z;

    double r_squared = dx * dx + dy * dy + dz * dz;
    double r = std::sqrt(r_squared);
    double factor;
    if (r == 0) {
         factor = 0;
    }
    else {
         factor = k * this->q / (r_squared * r);
    }

    Ex = factor * std::abs(dx);
    Ey = factor * std::abs(dy);
    Ez = factor * std::abs(dz);
}

//access the computed electric field components
void ECE_ElectricField::getElectricField(double& Ex, double& Ey, double& Ez) {
    Ex = this->Ex;
    Ey = this->Ey;
    Ez = this->Ez;
}


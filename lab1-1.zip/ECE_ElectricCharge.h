/*
Author:  Hongkun Xiong
Date last modified: 24/9/2023
Organization: ECE6122 Class

Description:
A header file of ECE_ElectricCharge,it claims the member variables and function of class ECE_ElectricCharge.
*/


#pragma once
//Class ECE_ElectricCharge, include protected variables x,y,z q and Func setLocation and setCharge
class ECE_ElectricCharge {
protected:
    double x; // x-coordinate.
    double y; // y-coordinate.
    double z; // z-coordinate.
    double q; // charge of the point.

public:
    ECE_ElectricCharge(double x, double y, double z, double q);
    void setLocation(double x, double y, double z);
    void setCharge(double q);
};





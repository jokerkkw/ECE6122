/*
Author:  Hongkun Xiong
Date last modified: 24/9/2023
Organization: ECE6122 Class

Description:
A header file of ElectricField,it defines the ElectricField class, which inherits from the ECE_ElectricCharge class.
*/
#pragma once

#include "ECE_ElectricCharge.h"

class ECE_ElectricField : public ECE_ElectricCharge {
protected:
    double Ex; // Electric field in the x-direction.
    double Ey; // Electric field in the y-direction.
    double Ez; // Electric field in the z-direction.

public:
    ECE_ElectricField(double x, double y, double z, double q);
    void computeFieldAt(double x, double y, double z);
    void getElectricField(double& Ex, double& Ey, double& Ez);
};

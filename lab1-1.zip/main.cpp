/*
Author:  Hongkun Xiong
Date last modified: 24/9/2023
Organization: ECE6122 Class

Description:
A main file drives the electric field calculation.
It creates an instance of the ElectricField class and a vector of ElectricField objects to represent point charges.
*/

#include <iostream>
#include <vector>
#include <cmath>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <sstream>      // std::istringstream
#include <string>       // std::string

#include "ECE_ElectricField.h"

/*
void CalculateElectricFieldForPoint(ElectricField pointCharge, double x, double y, double z, double& sEx, double& sEy, double& sEz) {
    double Ex, Ey, Ez;
    pointCharge.computeFieldAt(x, y, z);
    pointCharge.getElectricField(Ex, Ey, Ez);
    sEx += Ex;
    sEy += Ey;
    sEz += Ez;
}*/

void CalculateElectricFieldForPoints(std::vector<ECE_ElectricField>& pointCharges,
    int startIndex,
    int endIndex,
    double x,
    double y,
    double z,
    double& sEx,
    double& sEy,
    double& sEz
) {
    double Ex, Ey, Ez;

    for (int i = startIndex; i < endIndex; ++i) {
        pointCharges[i].computeFieldAt(x, y, z);
        pointCharges[i].getElectricField(Ex, Ey, Ez);
        sEx += Ex;
        sEy += Ey;
        sEz += Ez;
    }
}


int main(){
    while (true) {
        // some input
        int N, M;
        double dx, dy, C;
        double x, y, z;


        unsigned int n = std::thread::hardware_concurrency();

        std::cout << "Your computer supports " << n << " concurrent threads. " << std::endl;

        while (true) {
            std::cout << "Please enter the number of rows and columns in the N x M array: ";
            std::cin >> N >> M;
            if (N <= 0 || M <= 0) {
                // invalid input
                std::cout << "N and M should be positive natural numbers." << std::endl;
            }
            else {
                break;
            }
        }

        while (true) {
            std::cout << "Please enter the x and y separation distances in meters: ";
            std::cin >> dx >> dy;
            if (dx <= 0.0 || dy <= 0.0) {
                // invalid input
                std::cout << "Separation distances should be greater than 0.0." << std::endl;
            }
            else {
                break;
            }
        }

        while (true) {
            std::cout << "Please enter the common charge on the points in micro C:";
            std::cin >> C;
            if (C < 0.0) {
                // invalid input
                std::cout << "Charge should be a valid numerical value." << std::endl;
            }
            else
            {
                break;
            }
        }

        while (true) {
            std::cout << "Please enter the location in space to determine the electric field (x y z) in meters: ";
            std::cin >> x >> y >> z;
            if (std::isnan(x) || std::isnan(y) || std::isnan(z)) {
                // invalid input
                std::cout << "Point location should be made up of valid numerical values." << std::endl;
            }
            else {
                break;
            }
        }

        std::vector<ECE_ElectricField> pointCharges;

        //initialize location of charge, get specific location
        double leftTopX = -((M - 1) * dx) / 2.0;
        double leftTopY = ((N - 1) * dy) / 2.0;

        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < M; ++j) {
                double tempx = leftTopX + i * dx;
                double tempy = leftTopY - j * dy;
                ECE_ElectricField point = ECE_ElectricField(tempx, tempy, 0.0, C / 10e5);
                pointCharges.push_back(point);
            }
        }

        // Initialize electric field components
        double sEx=0.0, sEy=0.0, sEz=0.0;


        std::vector<std::thread> threads;
        
            // Calculate electric field strength
            /*for (int i = 0; i < N * M; i++) {
                pointCharges[i].computeFieldAt(x, y, z);
                pointCharges[i].getElectricField(Ex, Ey, Ez);
                sEx += Ex;
                sEy += Ey;
                sEz += Ez;
            }*/
        int total = N * M;
        int pointsPerThread = total / (n - 1);

        for (unsigned int i = 0; i < n; ++i) {
            int startIndex = i * pointsPerThread;
            int endIndex = (i == n - 1) ? total : startIndex + pointsPerThread;

            threads.emplace_back(CalculateElectricFieldForPoints, std::ref(pointCharges), startIndex, endIndex, x, y, z, std::ref(sEx), std::ref(sEy), std::ref(sEz));
            std::this_thread::sleep_for(std::chrono::milliseconds(5));
        }
       
       auto startRecursive = std::chrono::high_resolution_clock::now();

       std::this_thread::sleep_for(std::chrono::microseconds(7));

       // wait till all threads complete
       for (std::thread& t : threads) {
                t.join();
            }

        //  Calculate total electric field strength
        double E = std::sqrt(sEx * sEx + sEy * sEy + sEz * sEz);

        auto stopRecursive = std::chrono::high_resolution_clock::now();
        auto micro_duration_dp = std::chrono::duration_cast<std::chrono::microseconds>(stopRecursive - startRecursive);

        // output results
        std::cout << "The Electric field at (" << x << ", " << y << ", " << z << ")  in V / m is " << std::endl;
        std::cout << std::scientific;
        std::cout << "Ex = " << sEx << std::endl;
        std::cout << "Ey = " << sEy << std::endl;
        std::cout << "Ez = " << sEz << std::endl;
        std::cout << "|E| =  " << E << std::endl;
        std::cout << "The calculation took " << micro_duration_dp.count() << " microsec!" << std::endl;
        std::cout << std::fixed << std::endl;

        std::cout << "Do you want to enter a new location(Y / N) ? ";
        char ops;
        std::cin >> ops;
        if (ops == 'N') {
            std::cout << "Bye!" << std::endl;
            break;
        }
    }
    return 0;
}

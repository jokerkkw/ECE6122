/*
Author:  Hongkun Xiong
Date last modified: 7/10/2023
Organization: ECE6122 Class

Description:
A main file drives the electric field calculation using OpenMP and multi-threading for acceleration.
*/
#include <iostream>
#include <vector>
#include <cmath>
#include <omp.h>
#include <chrono>

const double k = 9.0e9; // c and its unit is N��m^2/C^2

// defination of PointCharge
struct PointCharge {
    double x;
    double y;
    double z;
    double q;
};

// CalculateElectricField
void CalculateElectricField(const PointCharge& point, double x, double y, double z, double& Ex, double& Ey, double& Ez) {
    double xx = x - point.x;
    double xy = y - point.y;
    double xz = z - point.z;

    double r_squared = xx * xx + xy * xy + xz * xz;
    double r = std::sqrt(r_squared);

    double factor = k * point.q / (r_squared * r);

    Ex += factor * xx;
    Ey += factor * xy;
    Ez += factor * xz;
}

int main() {

    while (true) {

        int N, M;
        double dx, dy, C;
        double x, y, z;
        int numThreads;
   


        //unsigned int n = omp_get_num_procs();
        //std::cout << "Your computer supports " << n << " concurrent threads." << std::endl;


        while (true) {
            std::cout << "Please enter the number of threads to use: ";
            std::cin >> numThreads;
            if (numThreads <= 0 || numThreads >=16 ) {
                // invalid input
                std::cout << "Threads should be natural numbers and its value should be between 1 and 16." << std::endl;
            }
            else {
                break;
            }
        }

        while (true) {
            std::cout << "Please enter the number of rows and columns in the N x M array: ";
            std::cin >> N >> M;
            if (N <= 0 || M <= 0) {
                // invalid input
                std::cout << "N and M should be positive natural numbers." << std::endl;
            }
            else {
                break;
            }
        }

        while (true) {
            std::cout << "Please enter the x and y separation distances in meters: ";
            std::cin >> dx >> dy;
            if (dx <= 0.0 || dy <= 0.0) {
                // invalid input
                std::cout << "Separation distances should be greater than 0.0." << std::endl;
            }
            else {
                break;
            }
        }

        while (true) {
            std::cout << "Please enter the common charge on the points in micro C:";
            std::cin >> C;
            if (C < 0.0) {
                // invalid input
                std::cout << "Charge should be a valid numerical value." << std::endl;
            }
            else
            {
                break;
            }
        }

        while (true) {
            std::cout << "Please enter the location in space to determine the electric field (x y z) in meters: ";
            std::cin >> x >> y >> z;
            if (std::isnan(x) || std::isnan(y) || std::isnan(z)) {
                // invalid input
                std::cout << "Point location should be made up of valid numerical values." << std::endl;
            }
            else {
                break;
            }
        }

        // build vector to store PointCharge
        std::vector<PointCharge> pointCharges;
        double leftTopX = -((M - 1) * dx) / 2.0;
        double leftTopY = ((N - 1) * dy) / 2.0;

        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < M; ++j) {
                PointCharge point;
                point.x = leftTopX + i * dx;
                point.y = leftTopY - j * dy;
                point.z = 0;
                point.q = C / 10e5;
                pointCharges.push_back(point);
            }
        }

        // Initiate electric field 
        double Ex = 0.0, Ey = 0.0, Ez = 0.0;

        // create thread to caculate
        auto startRecursive = std::chrono::high_resolution_clock::now();

        //set Thread
        omp_set_num_threads(numThreads);

    //use openMP to accelerate 
     #pragma omp parallel for reduction(+:Ex, Ey, Ez)
        for (int i = 0; i < pointCharges.size(); ++i) {
            double localEx = 0.0, localEy = 0.0, localEz = 0.0;
            CalculateElectricField(pointCharges[i], x, y, z, localEx, localEy, localEz);
            Ex += localEx;
            Ey += localEy;
            Ez += localEz;
        }

        // compute total electric field
        double E = std::sqrt(Ex * Ex + Ey * Ey + Ez * Ez);

        auto stopRecursive = std::chrono::high_resolution_clock::now();
        auto micro_duration_dp = std::chrono::duration_cast<std::chrono::microseconds>(stopRecursive - startRecursive);

        // output outcome
        std::cout << "Electric field at (" << x << ", " << y << ", " << z << "):" << std::endl;
        std::cout << std::scientific;
        std::cout << "Ex = " << Ex << std::endl;
        std::cout << "Ey = " << Ey << std::endl;
        std::cout << "Ez = " << Ez << std::endl;
        std::cout << "|E| =  " << E << std::endl;

        std::cout << "The calculation took " << micro_duration_dp.count() << " microsec!" << std::endl;
        std::cout << "Do you want to enter a new location(Y / N) ? ";
        char ops;
        std::cin >> ops;
        if (ops == 'N') {
            std::cout << "Bye!" << std::endl;
            break;
        }
    }
    return 0;
}

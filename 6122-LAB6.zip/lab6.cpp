/*
Author:  Hongkun Xiong
Date last modified: 28/11/2023
Organization: ECE6122 Class

Description:
Use OpenMPI to estimate the value of a definite integral using the Monte Carlo method
*/

#include <iostream>
#include <mpi.h>
#include <random>
#include <string>


// Function to compute the integral using Monte Carlo method.
double computeIntegral(int samples) {
    std::random_device rd;// Non-deterministic random number generator.
    std::mt19937 gen(rd());// Random number generator using Mersenne Twister.
    std::uniform_real_distribution<> dis(0, 1);

    int count = 0;
    for (int i = 0; i < samples; ++i) {
        double x = dis(gen);
        double y = dis(gen);
        if (y < x * x) { // Check if the point is below the curve y = x*x.
            count++;
        }
    }
    return static_cast<double>(count) / samples;
}


int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    int world_size;// Number of processes in the MPI world.
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    int world_rank;// Rank of the current process.
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);

    int N = 0; // Total number of samples.
    int P = 0; // Integral number to be estimated.
    // Parse command line arguments.
    if (argc > 3) {
        std::string paramP(argv[1]); // "-P"
        std::string paramN(argv[3]); // "-N"

        if (paramP == "-P" && paramN == "-N") {
        P = std::stoi(argv[2]);
        N = std::stoi(argv[4]);
        }
    }

    int local_samples = N / world_size;
    double local_estimate = computeIntegral(local_samples);

    double total_estimate; // Total estimate from all processes.
    // Reduce all local estimates to a total estimate.
    MPI_Reduce(&local_estimate, &total_estimate, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (world_rank == 0) {
        total_estimate /= world_size;
        std::cout << "The estimate for integral " << P << " is " << total_estimate << std::endl;
    }

    MPI_Finalize(); // Finalize the MPI environment.
    return 0;
}
